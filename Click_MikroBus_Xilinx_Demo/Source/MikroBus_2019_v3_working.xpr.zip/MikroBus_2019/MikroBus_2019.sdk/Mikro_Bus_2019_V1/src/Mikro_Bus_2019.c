//********************************************
/*
	   ____  ____
      /   /\/   /
	 /___/  \  /
     \   \   \/
	  \   \
	  /   /
	 /___/   /\
	 \   \  /  \
	  \___\/\___\

	Author: 		jeanchri
	Supervisor:		Jayson Bethurem
	Date: 			Aug 13th 2019
	Version:		1.0

*/

/***************************** Include Files **********************************/

#include "xparameters.h"
#include "xspi.h"
#include "xspi_l.h"
#include "xil_printf.h"
#include "xtmrctr.h"
#include "xgpio.h"
#include "xintc.h"
#include <stdio.h>


/************************** Initialize Periphral ******************************/
//Comment define if you do not need it

#define TIMER
#define GPIO
#define SPI
#define DELAY_TIM
#define BIT_SHIFT
#define BAR_GRAPH


/************************** Constant Definitions ******************************/
//SPi
#define SPI_DEVICE_ID       XPAR_SPI_0_DEVICE_ID
#define BASE_ADDR			XPAR_SPI_0_BASEADDR
#define SS_SPI				XPAR_SPI_0_NUM_SS_BITS
#define DTR_SPI				XPAR_SPI_0_NUM_TRANSFER_BITS

//Timer
#define TIMER_DEVICE_ID		XPAR_MIKROBUS_AXI_TIMER_0_DEVICE_ID
#define TIMER_BASE			XPAR_MIKROBUS_AXI_TIMER_0_BASEADDR
#define TIMER_COUNTER_0		0
#define DELAY				100000000	//<-----adjust the Time as you like

//GPIO
#define GPIO_DEVICE_ID_LED_LED  	XPAR_GPIO_2_DEVICE_ID
#define GPIO_DEVICE_ID_MIKROBUS		XPAR_GPIO_0_DEVICE_ID
#define LED_CHANNEL 1
#define MIKRO_CHANNEL 1


//PWM
#define PWM_PERIOD              500000000    /* PWM period in (500 ms) */
#define TMRCTR_0                0            /* Timer 0 ID */
#define TMRCTR_1                1            /* Timer 1 ID */
#define CYCLE_PER_DUTYCYCLE     10           /* Clock cycles per duty cycle */
#define MAX_DUTYCYCLE           100          /* Max duty cycle */
#define DUTYCYCLE_DIVISOR       4            /* Duty cycle Divisor */
#define WAIT_COUNT              PWM_PERIOD   /* Interrupt wait counter */

//Intc
#define INTC_DEVICE_ID          XPAR_INTC_0_DEVICE_ID
#define INTC_HANDLER            XIntc_InterruptHandler

/**************************** Type Definitions ********************************/
#define BUFFER_SIZE			3
u8 SendData[BUFFER_SIZE] = {0xFF, 0x03, 0x00};
u8 RecvData[BUFFER_SIZE];



//CHANGE DATA HERE

//Default Change
u32 WriteBuffer[BUFFER_SIZE] = {0x0F, 0xC0, 0xFF};


/***************** Macros (Inline Functions) Definitions **********************/


/************************** Function Prototypes *******************************/

int Spi_Test(u16 DeviceId, XSpi *SpiInstancePtr);
int XTmrCtr_Initialize(XTmrCtr * InstancePtr, u16 DeviceId);
void delay(int x);	//In milli_seconds
uint16_t BitShift(uint16_t bit);
int Mikro_BarGraph(u16 DeviceId, XSpi *SpiInstancePtr);
//int PWM_Light(XTmrCtr * InstancePtr);
//void reset_stuff(XTmrCtr * InstancePtr);
void Latch_LED_hold();
void Latch_LED_insert();
void Master_Reset();

/************************** Variable Definitions ******************************/

XSpi 			Spi; 		/* The instance of the SPI device */
XTmrCtr			Timer;
XGpio			Gpio;
XTmrCtr 		TimerCounterInst;  /* The instance of the Timer Counter */
XIntc			Intr;
XSpi_Config 	*ConfigPtr;
/*******************************************************************************/


int main(void)
{
	int Status;
	xil_printf("Executing Program... \r\n\n");

	/**********************************SETUP BLOCKS*************************************/

#ifdef TIMER
//Start timer to shift each bit
	Status = XTmrCtr_Initialize(&Timer, TIMER_DEVICE_ID);
	if (Status != XST_SUCCESS) {
	xil_printf("Timer Initialization Failed\r\n");
		return XST_FAILURE;
	}

	Status = XTmrCtr_SelfTest(&Timer, TIMER_COUNTER_0);
		if (Status != XST_SUCCESS) {
			xil_printf("Timer Initialization Failed\r\n");
			return XST_FAILURE;
		}
#endif



#ifdef GPIO
/* Initialize the GPIO driver -----LED TESTER----- */
//	Status = XGpio_Initialize(&Gpio, GPIO_DEVICE_ID_LED_LED);
//	if (Status != XST_SUCCESS) {
//		xil_printf("Gpio Initialization Failed\r\n");
//		return XST_FAILURE;
//	}
////Set as an Outpus
//	XGpio_SetDataDirection(&Gpio, LED_CHANNEL, 0);

//Mikro Bus Output
	Status = XGpio_Initialize(&Gpio, GPIO_DEVICE_ID_MIKROBUS);
	if (Status != XST_SUCCESS) {
		xil_printf("Gpio Initialization Failed\r\n");
		return XST_FAILURE;
	}
//Set as an Outpus
	XGpio_SetDataDirection(&Gpio, MIKRO_CHANNEL, 0);

#endif



#ifdef SPI
//Spi
	Status = Spi_Test(SPI_DEVICE_ID, &Spi);
	if (Status != XST_SUCCESS) {
	xil_printf("Spi  Failed TRY AGAIN\r\n");
	return XST_FAILURE;
	}
#endif



/**********************************START PROGRAM********************************/
//Set Low then Hgih
//	Master_Reset();
	 delay(1000);

//Hold latch off until data has been submitted
	 Latch_LED_hold();
//Shift Regs
	Mikro_BarGraph(SPI_DEVICE_ID, &Spi);

//Latches Enable
	Latch_LED_insert();
	xil_printf("Program Initiating... \r\n\n");

//delay(x) is in Milli_seconds
	while(1){

//Reset
//		Hold latch
		Latch_LED_hold();
//		Send Data
		Mikro_BarGraph(SPI_DEVICE_ID, &Spi);
//		Insert latch
		Latch_LED_insert();


//		 Wait
		 delay(1000);

//Reset
//		Hold latch
			Latch_LED_hold();
//		Send Data
			Mikro_BarGraph(SPI_DEVICE_ID, &Spi);
//		Insert latch
			Latch_LED_insert();

	}
    return 0;
}

/*****************************************************************************/







/**************************************************************************
*
* This function does a selftest and loopback test on the SPI device and
* XSpi driver as an example. The purpose of this function is to illustrate
* how to use the XSpi component.
*
*
* @param	DeviceId is the XPAR_<SPI_instance>_DEVICE_ID value from
*		xparameters.h
*
* @return	XST_SUCCESS if successful, XST_FAILURE if unsuccessful
*
* @note		None
*
****************************************************************************/
int Spi_Test(u16 DeviceId, XSpi *SpiInstancePtr)
{
	int Status;
	u32 Enable_Sys;
	u32 Control;
	u32 TX;
	u32 RX;
//	u32 Chip;
//	u32 Polarity;

//	***************************** SETUP *************************************
//Initialize block
	XSpi_Initialize(SpiInstancePtr, SPI_DEVICE_ID);

//	SpiInstancePtr->SendData = SendBufPtr;


	XSpi_Config *ConfigPtr;	/* Pointer to Configuration data */

	ConfigPtr = XSpi_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		return XST_DEVICE_NOT_FOUND;
	}

//Status of Device
	Status = XSpi_CfgInitialize(SpiInstancePtr, ConfigPtr,(ConfigPtr->DeviceId));
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}


//*******************************************************************************
	 xil_printf("\e[0;31m*****************\e[1;37mXilinx\e[0;31m********************\e[1;32m\r\n");


/*
 * Note:
 * 		DISABLE Loopback maybe??
 * 1) Enable SPI
 * 2) Inhibit transmit
 * 3) Master Mode
 * 4) Reset TX & RX fifo
 */

//ENABLE
	Enable_Sys = XSpi_ReadReg(BASE_ADDR, XSP_CR_OFFSET);
	Enable_Sys |= XSP_CR_ENABLE_MASK;
	Enable_Sys &= ~XSP_CR_TRANS_INHIBIT_MASK;
	XSpi_WriteReg(BASE_ADDR, XSP_CR_OFFSET, Enable_Sys);
	 xil_printf("Enabled System... \r\n");

//Make Master
	 Control = XSpi_ReadReg(BASE_ADDR, XSP_CR_OFFSET);
	 Control |= XSP_CR_MASTER_MODE_MASK;		//Make master mode
	 Control |= XSP_CR_TXFIFO_RESET_MASK;		//Reset TX
	 Control |= XSP_CR_RXFIFO_RESET_MASK;		//Reset RX
	 XSpi_WriteReg(BASE_ADDR, XSP_CR_OFFSET, Control);
	 xil_printf("Master Mode... \r\n");

//TX
	 TX = XSpi_ReadReg(BASE_ADDR, XSP_CR_OFFSET);
	 TX |= XSP_CR_TXFIFO_RESET_MASK;			//Reset TX
	 XSpi_WriteReg(BASE_ADDR, XSP_CR_OFFSET, TX);
//	 xil_printf("TX: %x... \r\n", TX);


//RX
	 RX = XSpi_ReadReg(BASE_ADDR, XSP_CR_OFFSET);
	 RX |= XSP_CR_TXFIFO_RESET_MASK;			//Reset TX
	 XSpi_WriteReg(BASE_ADDR, XSP_CR_OFFSET, RX);
//	 xil_printf("RX: %x... \r\n", RX);



//*******************************************************************************
//Start SPI
	XSpi_Start(&Spi);
	 xil_printf("\e[0;31m**************\e[1;37mRUNNING TEST\e[0;31m*****************\e[1;37m\r\n");

	 // Disable Global interrupt to use polled mode operation
	 XSpi_IntrGlobalDisable(&Spi);

/*	Transfer = XSpi_Transfer(SpiInstancePtr, SendData, RecvData, BUFFER_SIZE);
	xil_printf("Transfer Successful... \r\n");
	xil_printf("SPi: %x \r\n Send: %x \r\n Recv: %x \r\n Byte: %d  \r\n\n", Transfer);
xil_printf("	Spi: %x \r\n	SendData: %x \r\n	RecvData: %x \r\n	Byte: %x \r\n\n", Status);
*******************************************/
	return XST_SUCCESS;
}



  /*
Make a timer for the Spi protocal
Have it delay to 1000 ms and apply in spi
Timer 0
0-100000
and reset
*/

#ifdef DELAY_TIM
void delay(int x){
//Set a timer incremental (Change value of x [MS])
	u32 Timer_Value = 0;
	u32 ResetValue = 0;

	x= (x)*(25000);

	XTmrCtr_Enable(TIMER_BASE, TIMER_COUNTER_0);

	//Counter timer
	XTmrCtr_SetResetValue(&Timer, TIMER_COUNTER_0, ResetValue);
	XTmrCtr_Reset(&Timer, TIMER_COUNTER_0);
	XTmrCtr_Start(&Timer, TIMER_COUNTER_0);
	Timer_Value = XTmrCtr_GetValue(&Timer, TIMER_COUNTER_0);

	while (1) {
		Timer_Value = XTmrCtr_GetValue(&Timer, TIMER_COUNTER_0);
		//compare the value of timer
			if (Timer_Value > x){
//				xil_printf("Timer: %d \r\n", Timer_Value);
				//Read the stopped value
				XTmrCtr_Stop(&Timer,TIMER_COUNTER_0);
				XTmrCtr_Reset(&Timer, TIMER_COUNTER_0);
				break;
			}
	}
	XTmrCtr_Disable(TIMER_BASE, TIMER_COUNTER_0);

}
#endif
//*******************************************************************************


  /*
Make a bit shifter for ship
make a transfer after each
Split up into two

*/
#ifdef BIT_SHIFT
uint16_t BitShift(u16 bit){

	u8 first_byte;
	u8 second_byte;

	//Start shift
	second_byte = (uint8_t) bit;		//Cast the value to a u8
	bit = second_byte &(bit << 8);
	first_byte = bit;
	return first_byte;
}
#endif
//*******************************************************************************







/*Make a test file to check spi flow
8 bit shift register to mimic the chip
return in main
*/
#ifdef BAR_GRAPH
int Mikro_BarGraph(u16 DeviceId, XSpi *SpiInstancePtr){


	int i;
	u32 Test;

//************************** TEST 1 *********************************************
	 xil_printf("Test Transfer ... \r\n");

//Reset mode
	 Master_Reset();



//write DTR Register
//	 XSP_DTR_OFFSET
	XSpi_WriteReg(ConfigPtr->BaseAddress, XSP_CR_OFFSET, 0x1A2);
	Test = XSpi_ReadReg(BASE_ADDR, XSP_DTR_OFFSET);
	xil_printf("DTR: %x  \n\r", Test);

	//Loop to store Data
	for(i=0;i<3;i++){ // write in bytes to send
		XSpi_WriteReg( BASE_ADDR, XSP_DTR_OFFSET, WriteBuffer[i]);
	}

	return XST_SUCCESS;
}
#endif
//*******************************************************************************




void Latch_LED_hold(){
	u32 Latch;

 //DIS-ASSERT Chip Select
	 Latch =  XSpi_ReadReg(BASE_ADDR, XSP_SSR_OFFSET);
	 Latch &= ~0x01;
	 XSpi_WriteReg(BASE_ADDR, XSP_SSR_OFFSET, Latch);
	 xil_printf("Latch Off: %x... \r\n", Latch);
//	 Delay to give time***********************8
	 delay(100);
}



 void Latch_LED_insert(){
	 u32 Latch;

	 //ASSERT Chip Select
	 Latch =  XSpi_ReadReg(BASE_ADDR, XSP_SSR_OFFSET);
	 Latch |= 0x01;
	 XSpi_WriteReg(BASE_ADDR, XSP_SSR_OFFSET, Latch);
	 xil_printf("Latch On: %x... \r\n", Latch);
	 delay(100);
}


void Master_Reset(){
	 XGpio_DiscreteWrite(&Gpio, LED_CHANNEL, ~0x1);
//	 xil_printf("MR LOW _HIGH");
	 XGpio_DiscreteWrite(&Gpio, LED_CHANNEL, 0x1);
}


/*
int PWM_Light(XTmrCtr * InstancePtr){

	u8  DutyCycle;
//	u8  Div;
	u32 Period;
	u32 HighTime;
	u32 Max_100 = 1;


//	 Enable PWM
	XTmrCtr_PwmEnable(InstancePtr);

//	Div = DUTYCYCLE_DIVISOR;

//	 Configure PWM
	Period = PWM_PERIOD;
	HighTime = PWM_PERIOD / Max_100;
	DutyCycle = XTmrCtr_PwmConfigure(InstancePtr, Period, HighTime);

	xil_printf("PWM Configured for Duty Cycle = %d \r\n", DutyCycle);

//	Disable PWM
	XTmrCtr_PwmDisable(InstancePtr);
	return XST_SUCCESS;
}

void reset_stuff(XTmrCtr * InstancePtr){
	//For LED bliking

	XTmrCtr_Reset(InstancePtr,XTC_TIMER_0);
	XTmrCtr_Reset(InstancePtr,XTC_TIMER_1);
}
*/





