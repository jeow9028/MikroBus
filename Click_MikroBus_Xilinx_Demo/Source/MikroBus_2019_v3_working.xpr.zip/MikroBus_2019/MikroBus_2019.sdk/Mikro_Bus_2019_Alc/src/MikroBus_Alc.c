/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*********************************************

	   ____  ____
      /   /\/   /
	 /___/  \  /
     \   \   \/
	  \   \
	  /   /
	 /___/   /\
	 \   \  /  \
	  \___\/\___\

	Author: 		Jean-Christophe Owens (jeanchri)
	Supervisor:		Jayson Bethurem
	Date: 			Aug 22nd 2019
	Version:		1.0

**********************************************/



/***************************** Include Files **********************************/
#include <stdio.h>
#include "xil_printf.h"
#include <stdio.h>
#include "xspi.h"
#include "xspi_l.h"
#include "xtmrctr.h"
#include "xgpio.h"
#include "xintc.h"
#include "xuartlite.h"
#include "xparameters.h"
#include "xintc.h"
#include "xiic.h"
#include "xil_exception.h"




/************************** Initialize Periphral ******************************/
//Comment define if you do not need it
#define IIC
#define DELAY_TIM
#define TIMER
#define ALCVAL
#define GPIO
#define INTC_ALC





//*****************************************************************************
//Registers for Device
#define TIACN 		0x10
#define REFCN		0x11

//*****************************************************************************


//i2c_Alc
#define IIC_DEVICE_ID				XPAR_MIKROBUS_AXI_IIC_0_DEVICE_ID
#define BASE_I2C_ALC				XPAR_MIKROBUS_AXI_IIC_0_BASEADDR
#define EEPROM_TEST_START_ADDRESS   128
#define PAGE_SIZE   				3
#define SENSOR_ADDR					0b100100			//LMP91000 Address for Device


//Timer
#define TIMER_DEVICE_ID				XPAR_MIKROBUS_AXI_TIMER_0_DEVICE_ID
#define TIMER_BASE					XPAR_MIKROBUS_AXI_TIMER_0_BASEADDR
#define TIMER_COUNTER_0				0
#define DELAY						100000000	//<-----adjust the Time as you like


//GPIO
#define GPIO_DEVICE_ID_LED_LED  	XPAR_GPIO_2_DEVICE_ID
#define GPIO_DEVICE_ID_MIKROBUS		XPAR_GPIO_0_DEVICE_ID
#define MIKRO_CHANNEL 				1

//INTC
#define I2C_ALC_VEC_ID				XPAR_INTC_0_IIC_0_VEC_ID
#define INTC_DEVICE_ID				XPAR_INTC_0_DEVICE_ID
#define INTC						XIntc





/************************** Function Prototypes *******************************/
//Setup i2c_Alc
int i2c_Alc_Test(u16 DeviceId,XIic *InstancePtr);

//Timer
void delay(int x);

//RST PIN
void Set_Low();
void Set_High();
void Master_Reset();

//i2c_Alc Functions
int WriteData(u16 ByteCount);
int ReadData(u8 *BufferPtr, u16 ByteCount);
int ReadFromReg(u8 buf1, u8 buf2);
int WritetoReg(u8 buf1, u8 buf2, u8 buf3);

//Intr Functions
static int SetupInterruptSystem(XIic *IicInstPtr);
static void SendHandler(XIic *InstancePtr);
static void ReceiveHandler(XIic *InstancePtr);
static void StatusHandler(XIic *InstancePtr, int Event);




/************************** Variable Definitions ******************************/
XGpio			Gpio;
XIic			i2c_Alc;
XTmrCtr			Timer;
XIic_Config 	*ConfigPtr;					/* Pointer to configuration data */
XTmrCtr 		TimerCounterInst;  			/* The instance of the Timer Counter */
XIntc			InterruptController;

typedef u8 AddressType;
AddressType Address = SENSOR_ADDR;




/**************************** Type Definitions ********************************/
u8 WriteBuffer[sizeof(AddressType) + PAGE_SIZE];
u8 ReadBuffer[PAGE_SIZE]; /* Read buffer for reading a page. */
u8 DataBuf[PAGE_SIZE];

/*****************************************************************************/
//Volatile interrupt Flags
volatile int TransmitComplete = FALSE;
volatile int ReceiveComplete = FALSE;




int main()
{
    u32 Status;
    u32 Data;
	xil_printf("\e[0;31m*****************\e[1;37mXilinx\e[0;31m********************\e[1;32m\r\n");
	xil_printf("Executing Program... \r\n\n");



//***************************************************************

#ifdef TIMER
//Start timer to shift each bit
	Status = XTmrCtr_Initialize(&Timer, TIMER_DEVICE_ID);
	if (Status != XST_SUCCESS) {
	xil_printf("Timer Initialization Failed\r\n");
		return XST_FAILURE;
	}
#endif
//***************************************************************

#ifdef GPIO
//Mikro Bus Output
		Status = XGpio_Initialize(&Gpio, GPIO_DEVICE_ID_MIKROBUS);
		if (Status != XST_SUCCESS) {
			xil_printf("Gpio Initialization Failed\r\n");
			return XST_FAILURE;
		}
//Set direction as an Output
		XGpio_SetDataDirection(&Gpio, MIKRO_CHANNEL, 0);

#endif

/*********************Make MENB Low for I2C**********************/
//Set High after Transmission is complete
	Set_High();
//Set Low before Transmission is complete
	Set_Low();
/****************************************************************/


#ifdef INTC_ALC
//Set up Interrupts
	Status = SetupInterruptSystem(&i2c_Alc);
	if (Status != XST_SUCCESS) {
		xil_printf("INTC_ALC Initialization Failed\r\n");
		return XST_FAILURE;
	}

	Status = i2c_Alc_Test(IIC_DEVICE_ID, &i2c_Alc);
   	if (Status != XST_SUCCESS) {
   		xil_printf("IIC Initialization Failed\r\n");
   		return XST_FAILURE;
   	}

//Set the Transmit, Receive and Status handlers.
	XIic_SetSendHandler(&i2c_Alc, &i2c_Alc,(XIic_Handler) SendHandler);
	XIic_SetRecvHandler(&i2c_Alc, &i2c_Alc,(XIic_Handler) ReceiveHandler);
	XIic_SetStatusHandler(&i2c_Alc, &i2c_Alc,(XIic_StatusHandler) StatusHandler);

	XIic_IntrGlobalEnable(i2c_Alc.BaseAddress);

   	#endif

//***************************************************************

#ifdef IIC
   	Status = i2c_Alc_Test(IIC_DEVICE_ID, &i2c_Alc);
   	if (Status != XST_SUCCESS) {
   		xil_printf("IIC Initialization Failed\r\n");
   		return XST_FAILURE;
   	}
#endif




//***************************************************************
    xil_printf("\e[0;31m**************\e[1;37mRUNNING TEST\e[0;31m*****************\e[1;37m\r\n");
//***************************************************************


/*Configure the Device before reading*/
	xil_printf("Writing to register... \r\n");

/*
//	Inputs for function below for the Register in DEVICE!!!!

//	Write to lock to Write
	WritetoReg(0x00, 0x01, 0x00);
//	Write to TIACN
	WritetoReg(0x10, 0x00, 0x04);
//	Write to Control regsiter
	WritetoReg(0x00, 0x11, 0b0011);
*/





	while(1){


		if(TransmitComplete){
			xil_printf("test 1 \r\n");
		}



		if (ReceiveComplete){
			xil_printf("test 2 \r\n");
		}

/*

//Reading from register
		xil_printf("\e[1;37mReading from register... \r\n");

		Data = ReadFromReg(0x00, 0x10);
		xil_printf("Alcoloh reads: %d \r\n", Data);

//Wait 1000ms
		delay(1000);
break;*/
		}


	xil_printf("End of Program");
	return 0;
}



/*****************************************************************/














/*****************************************************************************/
/**
*
* This function does a selftest on the IIC device and XIic driver as an
* example.
*
* @param	DeviceId is the XPAR_<IIC_instance>_DEVICE_ID value from
*		xparameters.h.
*
* @return	XST_SUCCESS if successful, XST_FAILURE if unsuccessful.
*
* @note		None.
*
****************************************************************************/
int i2c_Alc_Test(u16 DeviceId, XIic *InstancePtr)
{

	int Status;


//Initialize the IIC driver so that it is ready to use.

	XIic_Initialize(InstancePtr, DeviceId);

	ConfigPtr = XIic_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		return XST_FAILURE;
	}

	Status = XIic_CfgInitialize(InstancePtr, ConfigPtr, ConfigPtr->BaseAddress);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}


//Configuring the interrupt controller
	Status = SetupInterruptSystem(InstancePtr);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}


//*****************************************************************************
//********************************Configurations*******************************
/*


//Enable
	Enable_Sys |= XIIC_CR_ENABLE_DEVICE_MASK;
	XIic_WriteReg(BASE_I2C_ALC, XIIC_CR_REG_OFFSET, Enable_Sys);
	xil_printf("Enabled System... \r\n");



 //Set  MSMS -> 1
	 TxWrite = XIic_ReadReg(BASE_I2C_ALC, XIIC_CR_REG_OFFSET);
	 TxWrite |= XIIC_CR_MSMS_MASK;
	 XIic_WriteReg(BASE_I2C_ALC, XIIC_CR_REG_OFFSET, TxWrite);
	 xil_printf("Master txing.. \r\n");


 //Repeated Start
	 TxWrite = XIic_ReadReg(BASE_I2C_ALC, XIIC_CR_REG_OFFSET);
	 TxWrite |=  XIIC_CR_REPEATED_START_MASK;
	 XIic_WriteReg(BASE_I2C_ALC, XIIC_CR_REG_OFFSET, TxWrite);
	 xil_printf("Repeated Start.. \r\n");



//Write Device address
	 Status = XIic_SetAddress(&i2c_Alc, XII_ADDR_TO_SEND_TYPE, XII_SEND_10_BIT_OPTION);
	 	 if (Status != XST_SUCCESS) {
	 		 return XST_FAILURE;
	 	 }


//Set MSMS -> 0
	 TxWrite = XIic_ReadReg(BASE_I2C_ALC, XIIC_CR_REG_OFFSET);
	 TxWrite &= ~XIIC_CR_MSMS_MASK;
	 XIic_WriteReg(BASE_I2C_ALC, XIIC_CR_REG_OFFSET, TxWrite);
	 xil_printf("Master txing stop.. \r\n \e[0;37m");

*/


	return XST_SUCCESS;
}
//*****************************************************************************




#ifdef DELAY_TIM
void delay(int x){
//Set a timer incremental (Change value of x [MS])
	u32 Timer_Value = 0;
	u32 ResetValue = 0;

	x= (x)*(25000);

	XTmrCtr_Enable(TIMER_BASE, TIMER_COUNTER_0);

	//Counter timer
	XTmrCtr_SetResetValue(&Timer, TIMER_COUNTER_0, ResetValue);
	XTmrCtr_Reset(&Timer, TIMER_COUNTER_0);
	XTmrCtr_Start(&Timer, TIMER_COUNTER_0);
	Timer_Value = XTmrCtr_GetValue(&Timer, TIMER_COUNTER_0);

	while (1) {
		Timer_Value = XTmrCtr_GetValue(&Timer, TIMER_COUNTER_0);
		//compare the value of timer
			if (Timer_Value > x){
//				xil_printf("Timer: %d \r\n", Timer_Value);
				//Read the stopped value
				XTmrCtr_Stop(&Timer,TIMER_COUNTER_0);
				XTmrCtr_Reset(&Timer, TIMER_COUNTER_0);
				break;
			}
	}
	XTmrCtr_Disable(TIMER_BASE, TIMER_COUNTER_0);

}
#endif









void Set_Low(){
	u32 low;
	 XGpio_DiscreteWrite(&Gpio, MIKRO_CHANNEL, 0x00);
	 low = XGpio_DiscreteRead(&Gpio, MIKRO_CHANNEL);
	 xil_printf("MENB LOW: %d \r\n", low);
}

void Set_High(){
	u32 high;
	 XGpio_DiscreteWrite(&Gpio, MIKRO_CHANNEL, 0x01);
	 high = XGpio_DiscreteRead(&Gpio, MIKRO_CHANNEL);
	 xil_printf("MENB HIGH: %d \r\n", high);
}


void Master_Reset(){
	 XGpio_DiscreteWrite(&Gpio, MIKRO_CHANNEL, ~0x1);
//	 xil_printf("MR LOW _HIGH");
	 XGpio_DiscreteWrite(&Gpio, MIKRO_CHANNEL, 0x1);
}



















int WriteData(u16 ByteCount)
{
	int Status;
	int count;
	 //Set the defaults.

//	TransmitComplete = 1;
	i2c_Alc.Stats.TxErrors = 0;

//Start the IIC device.
	Status = XIic_Start(&i2c_Alc);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

//Send the Data.
	//xil_printf("Sending Data\n\r");
	Status = XIic_MasterSend(&i2c_Alc, WriteBuffer, ByteCount);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	xil_printf("Master Send... \r\n");


/*DEBUGGING
	 Status = XIic_ReadReg(BASE_I2C, XIIC_SR_REG_OFFSET);		//Read status register of IIC
	 xil_printf("Status Reg: %x \n\r", Status);
	 if (Status == 0x40){
		 xil_printf("\e[0;31m FIFO Empty \e[0;37m \r\n\n");
	 }

*/



	//Wait till all the data is received.
	while((!TransmitComplete) || (XIic_IsIicBusy(&i2c_Alc) == TRUE)) {
		xil_printf("Flag up \r\n");
		count++;

		if (i2c_Alc.Stats.TxErrors != 0) {

		//FAILS HEREE *@**@$*H@ DJNW@ADPN


		 //Enable the IIC device.
			Status = XIic_Start(&i2c_Alc);
			if (Status != XST_SUCCESS) {
				return XST_FAILURE;
			}

			//Send the Data if the bus is not busy
			if (!XIic_IsIicBusy(&i2c_Alc)) {
				Status = XIic_MasterSend(&i2c_Alc,
							 WriteBuffer,
							 ByteCount);

			if (Status == XST_SUCCESS) {
					i2c_Alc.Stats.TxErrors = 0;
				}
			else {
				}
			}
		}
	}






	 //Stop the IIC device.
	Status = XIic_Stop(&i2c_Alc);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

/*
	 Status = XIic_ReadReg(BASE_I2C_ALC, XIIC_SR_REG_OFFSET);		//Read status register of IIC
	 xil_printf("Status Reg: %x \n\r", Status);
	 if (Status == 0x40){
		 xil_printf("\e[0;31m FIFO Empty \e[0;37m \r\n\n");
	 }
*/
	return XST_SUCCESS;
}















int ReadData(u8 *BufferPtr, u16 ByteCount)
{
	int Status;
	int count;
//Set Falg to 0 Default state



//Start the IIC device.
	Status = XIic_Start(&i2c_Alc);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

//Receive the Data.

	Status = XIic_MasterRecv(&i2c_Alc, BufferPtr, ByteCount);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	xil_printf("Master Receive... \r\n");

	 //Wait till all the data is received.
		while((!ReceiveComplete) || (XIic_IsIicBusy(&i2c_Alc) == TRUE)) {
			xil_printf("RX Flag up \r\n");
			count++;
		}

	 //Stop the IIC device.
	Status = XIic_Stop(&i2c_Alc);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	 Status = XIic_ReadReg(BASE_I2C_ALC, XIIC_SR_REG_OFFSET);		//Read status register of IIC
	 xil_printf("Status Reg: %x \n\r", Status);
	 if (Status == 0x40){
		 xil_printf("\e[0;31m FIFO Empty \e[0;37m \r\n\n");
	 }
	return XST_SUCCESS;
}





int ReadFromReg(u8 buf1, u8 buf2){
	int Status;
	u8 Index;

    WriteBuffer[0] = buf1;
    WriteBuffer[1] = buf2;

	for (int Index = 0; Index < PAGE_SIZE; Index++) {
		WriteBuffer[2 + Index] = 0xFF;
		ReadBuffer[Index] = 0;
	}

	//xil_printf("Sending data to %x: \n\r", SENSOR_ADDR);    					//For debug
    Status = XIic_SetAddress(&i2c_Alc, XII_ADDR_TO_SEND_TYPE, SENSOR_ADDR);			//Sets the IIC device address to talk with. Address is shifted by 1.
	if (Status != XST_SUCCESS) {
		xil_printf("\n\rIIC XIic_SetAddress Failed \n\r");
		return XST_FAILURE;
	}
	//xil_printf("Starting write\n\r");											//For debug
    WriteData(2);																//Write 2 bytes of data on the IIC bus

	//xil_printf("Reading data from %x: \n\r", SENSOR_ADDR);					//For debug
    Status = ReadData(ReadBuffer, 1);
    if(Status != XST_SUCCESS) xil_printf("\n\rIIC Read Failed @ 0x%02x%02x: with Value 0x%02x: \n\r", WriteBuffer[0],  WriteBuffer[1], ReadBuffer[0]);
    	        else xil_printf("\n\rIIC Read Successful @ 0x%02x%02x: with Value 0x%02x: \n\r", WriteBuffer[0],  WriteBuffer[1], ReadBuffer[0]);
    return ReadBuffer[0];
}




int WritetoReg(u8 buf1, u8 buf2, u8 buf3){
	//int val1, val2, val3;
	//YESSS IMPORTANT!
	//0x300B register read for device ID
	int Status;
	int i;

	WriteBuffer[0] = buf1;
	WriteBuffer[1] = buf2;
	WriteBuffer[2] = buf3;


	for(i=0;i<3;i++){ // write in bytes to send
		XIic_WriteReg( BASE_I2C_ALC, XIIC_DTR_REG_OFFSET, WriteBuffer[i]);
	}



	//xil_printf("sending data to %x: \n\r", SENSOR_ADDR);
	Status = XIic_SetAddress(&i2c_Alc, XII_ADDR_TO_SEND_TYPE, SENSOR_ADDR);
	if (Status != XST_SUCCESS) {
		xil_printf("\n\rIIC XIic_SetAddress Failed \n\r");
		return XST_FAILURE;
	}

	WriteData(3);

	return XST_SUCCESS;
}



static int SetupInterruptSystem(XIic *InstancePtr)
{
	int Status;

	if (InterruptController.IsStarted == XIL_COMPONENT_IS_STARTED) {
		return XST_SUCCESS;
	}


	 //Initialize the interrupt controller driver so that it's ready to use, specify the device ID that is generated in xparameters.h
	Status = XIntc_Initialize(&InterruptController, INTC_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	 //Connect a device driver handler that will be called when an interrupt for the device occurs, the device driver handler performs the specific interrupt processing for the device
	Status = XIntc_Connect(&InterruptController, I2C_ALC_VEC_ID,
				   (XInterruptHandler) XIic_InterruptHandler,
				   InstancePtr);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	 //Start the interrupt controller such that interrupts are recognized and handled by the processor.
	Status = XIntc_Start(&InterruptController, XIN_REAL_MODE);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	 //Enable the interrupts for the IIC device.
	XIntc_Enable(&InterruptController, I2C_ALC_VEC_ID);

	//Initialize the exception table.
	Xil_ExceptionInit();


	 //Register the interrupt controller handler with the exception table.
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
				 (Xil_ExceptionHandler) XIntc_InterruptHandler,
				 &InterruptController);

	 //Enable non-critical exceptions.
	Xil_ExceptionEnable();

	return XST_SUCCESS;

}




















//*****************************************************************************
//									Handler Interrupts
/*****************************************************************************/
/**
* This Send handler is called asynchronously from an interrupt context and
* indicates that data in the specified buffer has been sent.
*
* @param	InstancePtr is a pointer to the IIC driver instance for which
* 		the handler is being called for.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
static void SendHandler(XIic *InstancePtr)
{
	TransmitComplete = TRUE;
	xil_printf("Test 1 \r\n");

}

/*****************************************************************************/
/**
* This Receive handler is called asynchronously from an interrupt context and
* indicates that data in the specified buffer has been Received.
*
* @param	InstancePtr is a pointer to the IIC driver instance for which
* 		the handler is being called for.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
static void ReceiveHandler(XIic *InstancePtr)
{
	ReceiveComplete = TRUE;
	xil_printf("Test 2 \r\n");
}

/*****************************************************************************/
/**
* This Status handler is called asynchronously from an interrupt
* context and indicates the events that have occurred.
*
* @param	InstancePtr is a pointer to the IIC driver instance for which
*		the handler is being called for.
* @param	Event indicates the condition that has occurred.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
static void StatusHandler(XIic *InstancePtr, int Event)
{

}







